import React from 'react';
import ReactDOM from 'react-dom/client';
import '../app/globals.css';
import PadelGame from '../app/padel-game';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <PadelGame />
  </React.StrictMode>,
);
